## compile and run decryption code

   ```bash
    g++ decrypt.c -o decryption 
    ./decryption

