g++ exercises.cpp -o th -pthread

./th <NUM_THREADS> <NUM_INCREMENTS>